public class G extends null {

    java.util.List<String> jj();

    double ee();
}
