public class B extends null {

    java.lang.Class qq();

    String kk();
}
