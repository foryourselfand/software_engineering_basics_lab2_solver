public class D extends E {

    private byte d = 1;

    private int i = 42;

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public byte oo() {
        return 3;
    }

    public long ac() {
        return 222;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object rr() {
        return null;
    }
}
