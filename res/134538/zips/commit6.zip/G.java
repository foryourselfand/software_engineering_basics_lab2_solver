public interface G {

    java.util.List<String> jj();

    double ee();
}
