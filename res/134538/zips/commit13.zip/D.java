public class D extends E {

    private byte d = 1;

    private int i = 42;

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public byte oo() {
        return 3;
    }

    public long ac() {
        return 333;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object rr() {
        return null;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public void ab() {
        return;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public long dd() {
        return 100500;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
