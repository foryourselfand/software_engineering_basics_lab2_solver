public class G extends null {

    java.util.List<String> jj();

    double ee();

    public java.lang.Class qq() {
        return getClass();
    }
}
