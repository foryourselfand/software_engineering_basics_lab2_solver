public class B extends null {

    java.lang.Class qq();

    String kk();

    public int ae() {
        return java.lang.Math.abs(-7);
    }
}
