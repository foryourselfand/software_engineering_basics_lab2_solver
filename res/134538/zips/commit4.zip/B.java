public interface B {

    java.lang.Class qq();

    String kk();
}
